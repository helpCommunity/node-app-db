// Stores the background page in a JS object
var background = chrome.extension.getBackgroundPage();

maskUID = function() {
    const UID_STR = background.uid.toString();
    let str = "";
    for (let i = UID_STR.length - 1; i >= 0; i--) {
        str += String.fromCharCode((parseInt(UID_STR[i])) + 97);
    }
    return str;
}

$(function() {
    $('#UID').ready(function(){
        if (background.uid != -1) {
            
            $('#UID').text(maskUID());
        }
        else {
            $('#UID').text("UID not connected");
        }
    })
});

$(function() {
    $('#status').ready(function(){
        if (background.uid === -1) {
            $('#status').text("Not connected to Toloka");
        }
        else {
            $('#status').text("Connected to Toloka");
        }
    })
});

/*
// Loads button text properly 
$(function() {
    $('#power').ready(function(){
        if (background.isOn === true) {
            $('#power').text("Turn Off");
        }
        else {
            $('#power').text("Turn On");
        }
    })
});

// Couples the toggle button to the toggle functionality
$(function() {
    $('#power').click(function(){
        background.toggle();
        if (background.isOn === true) {
            $('#power').text("Turn Off");
        }
        else {
            $('#power').text("Turn On");
        }
    })
});

$(function() {
    $('#tasks').click(function(){
        //background.processTasks();
        background.handleTasks();
    })
});

$(function() {
    $('#income').click(function(){
        background.handleReciepts();
    })
});

$(function() {
    $('#user').click(function(){
        background.handleWorker();
    })
});
*/
